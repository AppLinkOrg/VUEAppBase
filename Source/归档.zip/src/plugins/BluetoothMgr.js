
export class BluetoothMgr{

 
} 
